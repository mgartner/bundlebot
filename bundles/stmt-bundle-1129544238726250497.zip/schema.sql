USE defaultdb;
CREATE TABLE public.users (
	id UUID NOT NULL,
	email STRING NOT NULL,
	first_name STRING NOT NULL,
	last_name STRING NOT NULL,
	created_at TIMESTAMPTZ NULL,
	CONSTRAINT users_pkey PRIMARY KEY (id ASC),
	UNIQUE INDEX users_email_key (email ASC),
	INDEX users_last_name_idx (last_name ASC)
);
