ALTER TABLE defaultdb.public.users INJECT STATISTICS '[]';
