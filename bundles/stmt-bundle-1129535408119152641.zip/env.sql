-- Version: CockroachDB CCL v25.2.4 (aarch64-apple-darwin21.2, built 2025/07/31 21:22:10, go1.23.7 X:nocoverageredesign)

-- User: demo

SET application_name = '$ cockroach demo';  -- default value: 
-- read-only authentication_method = cert-password
SET database = 'defaultdb';  -- default value: 
SET direct_columnar_scans_enabled = off;  -- default value: off
-- read-only is_superuser = on
-- read-only locality = region=us-east1,az=b
-- read-only node_id = 1
-- read-only results_buffer_size = 524288
-- read-only session_id = 187dbf6b42b498000000000000000001
SET sql_safe_updates = on;  -- default value: off
-- read-only ssl = on
-- read-only transaction_priority = normal
-- read-only transaction_status = NoTxn

SET CLUSTER SETTING cluster.organization = 'Cockroach Demo';  -- default value: 
SET CLUSTER SETTING kv.rangefeed.enabled = 'true';  -- default value: false
