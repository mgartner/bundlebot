SELECT
  *
FROM
  users
WHERE
  last_name = 'Doe' AND created_at >= '2025-01-01'
ORDER BY
  create_at DESC
LIMIT
  25